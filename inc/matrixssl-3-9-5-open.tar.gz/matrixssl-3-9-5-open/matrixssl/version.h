/*
    Copyright 2017 INSIDE Secure Corporation 
    This file is auto-generated
*/ 
#ifndef _h_MATRIXSSL_VERSION
#define _h_MATRIXSSL_VERSION
#ifdef __cplusplus
extern "C" {
#endif

#define MATRIXSSL_VERSION      "3.9.5-OPEN"
#define MATRIXSSL_VERSION_MAJOR 3
#define MATRIXSSL_VERSION_MINOR 9
#define MATRIXSSL_VERSION_PATCH 5
#define MATRIXSSL_VERSION_CODE "OPEN"

#ifdef __cplusplus
}
#endif
#endif /* _h_MATRIXSSL_VERSION */

